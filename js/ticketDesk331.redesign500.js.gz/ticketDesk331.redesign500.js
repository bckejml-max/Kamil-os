import {h,money,formModal,modal,toast} from './utils.js';
import {
  loadTicketCloud660,
  scanTicketsNow660,
  markTicketAlertsSeen660,
  updateTicketTracking660,
  upsertTicketInventory660
} from './ticketCloud660.js';
import {openTicketExcelImport660,exportTicketInventory660,openTicketRecoveryCenter185} from './ticketImport660.js';
import {openTicketCommander660} from './ticketCommander660.js';

const n=x=>Number(x||0);
const ACTIVE=new Set(['LISTED','NOT_LISTED']);
const SOLD=new Set(['SOLD_UNDELIVERED','SOLD_WAITING_PAYMENT','PAYOUT_RECEIVED','PAID']);
const PAID=new Set(['PAYOUT_RECEIVED','PAID']);
const MODE_SET=new Set(['inventory','purchases','sold','all','opportunities']);
const COLUMNS=['date','platform','qty','buy','sell','profit','status'];
const code=s=>String(s?.recommendation_code||'').toUpperCase();
const latest=(cloud,id)=>cloud.latest?.get(id)||null;
const active=r=>ACTIVE.has(String(r?.market_status||'').toUpperCase());
const sold=r=>SOLD.has(String(r?.market_status||'').toUpperCase());
const paid=r=>PAID.has(String(r?.market_status||'').toUpperCase());
const actionCode=s=>!['','HOLD','NO_PRICE','FETCH_ERROR','SOURCE_MISSING'].includes(code(s));
const status=x=>({
  LISTED:'Nabídnuto',
  NOT_LISTED:'Koupeno',
  SOLD_UNDELIVERED:'Doručit',
  SOLD_WAITING_PAYMENT:'Čeká platba',
  PAYOUT_RECEIVED:'Vyplaceno',
  PAID:'Vyplaceno'
})[String(x||'').toUpperCase()]||String(x||'Neurčeno');

function tone(s){
  const c=code(s);
  if(['LOWER','VERIFY_DATA','OFFICIAL_COMPETITION'].includes(c))return'critical';
  if(['LIST','RAISE','BUY'].includes(c))return'success';
  return'warning';
}

function verdict(s){
  const c=code(s);
  return({
    LIST:'PRODAT',LOWER:'ZLEVNIT',RAISE:'ZVÝŠIT',VERIFY_DATA:'OVĚŘIT',
    OFFICIAL_COMPETITION:'POZOR',HOLD:'DRŽET',NO_PRICE:'ČEKAT',
    SOURCE_MISSING:'DOPLNIT ZDROJ',FETCH_ERROR:'ZDROJ CHYBÍ'
  })[c]||String(s?.recommendation_label||'SLEDOVAT').toUpperCase();
}

function apiHealth(s){
  const vg=String(s?.viagogo_status||'').toUpperCase()==='LIVE'||n(s?.market_price_czk)>0;
  const sh=String(s?.stubhub_status||'').toUpperCase()==='LIVE'||n(s?.stubhub_price_czk)>0;
  return{vg,sh};
}

function confidence(s){
  const x=n(s?.multi_market_confidence);
  if(x>0)return Math.min(100,Math.round(x));
  const raw=String(s?.confidence||'').toLowerCase();
  if(raw.includes('official'))return 90;
  if(n(s?.market_price_czk))return 72;
  return 45;
}

function qty(r){return Math.max(1,n(r?.qty||1));}
function buyTotal(r){return n(r?.buy_total_czk)||n(r?.buy_each_czk)*qty(r);}
function sellTotal(r){return n(r?.sell_total_czk)||n(r?.sell_each_czk)*qty(r);}
function soldProfit(r){return sellTotal(r)-buyTotal(r);}
function potential(r,s){
  const rec=n(s?.recommended_ask_czk)||n(s?.market_price_czk)||n(r?.ask_each_czk);
  if(!rec||!n(r?.buy_each_czk))return null;
  return(rec-n(r.buy_each_czk))*qty(r);
}

function summary(cloud){
  const rows=cloud.inventory||[];
  const current=rows.filter(active);
  const soldRows=rows.filter(sold);
  let invested=0,potentialProfit=0,realizedProfit=0,paidProfit=0,pendingPayout=0,actions=0;
  for(const r of current){
    const s=latest(cloud,r.id);
    invested+=buyTotal(r);
    const p=potential(r,s);
    if(Number.isFinite(p))potentialProfit+=p;
    if(actionCode(s))actions++;
  }
  for(const r of soldRows){
    const p=soldProfit(r);
    realizedProfit+=p;
    if(paid(r))paidProfit+=p;
    else pendingPayout+=sellTotal(r);
  }
  return{
    current,soldRows,invested,potentialProfit,realizedProfit,paidProfit,pendingPayout,actions,
    boughtQty:rows.reduce((sum,r)=>sum+qty(r),0),
    activeQty:current.reduce((sum,r)=>sum+qty(r),0),
    soldQty:soldRows.reduce((sum,r)=>sum+qty(r),0)
  };
}

function eventDateParts(r){
  if(!r?.event_date)return{date:'Bez data',time:'—',iso:''};
  const d=new Date(r.event_date);
  if(Number.isNaN(+d))return{date:String(r.event_date),time:'—',iso:String(r.event_date)};
  return{
    date:new Intl.DateTimeFormat('cs-CZ',{day:'numeric',month:'numeric',year:'numeric'}).format(d),
    time:/T\d{2}:\d{2}/.test(String(r.event_date))?new Intl.DateTimeFormat('cs-CZ',{hour:'2-digit',minute:'2-digit'}).format(d):'—',
    iso:d.toISOString()
  };
}

function eventDate(r){return eventDateParts(r).date;}
const price=v=>n(v)>0?money(v):'—';
const signedMoney=v=>Number.isFinite(v)?`${v>=0?'+':''}${money(v)}`:'—';

function platform(r){
  const raw=[r?.source_name,r?.source_sheet,r?.viagogo_url,r?.stubhub_url,r?.official_url].filter(Boolean).join(' ').toLowerCase();
  if(raw.includes('viagogo'))return{name:'Viagogo',key:'viagogo'};
  if(raw.includes('stubhub'))return{name:'StubHub',key:'stubhub'};
  if(raw.includes('ticketmaster'))return{name:'Ticketmaster',key:'ticketmaster'};
  if(raw.includes('ticketportal'))return{name:'Ticketportal',key:'ticketportal'};
  if(raw.includes('ticketstream'))return{name:'Ticketstream',key:'ticketstream'};
  if(raw.includes('goout'))return{name:'GoOut',key:'goout'};
  const clean=String(r?.source_name||'Evidence').trim();
  return{name:clean&&clean!=='Excel import'?clean:'Evidence',key:'evidence'};
}

function visualFor(name=''){
  const x=String(name).toLowerCase();
  if(/nba|basket|knicks|lakers|bulls/.test(x))return{key:'basketball',icon:'◉'};
  if(/davis|tenis|tennis|atp|wta|wimbledon/.test(x))return{key:'tennis',icon:'●'};
  if(/f1|formula|grand prix|abu dhabi|monaco/.test(x))return{key:'racing',icon:'◆'};
  if(/hokej|nhl|ice hockey/.test(x))return{key:'hockey',icon:'✦'};
  if(/koncert|concert|festival|tour|arena show/.test(x))return{key:'music',icon:'♫'};
  if(/slavia|sparta|derby|football|fotbal|liga|champions| vs | – | - /.test(x))return{key:'football',icon:'⬡'};
  return{key:'event',icon:'◇'};
}

function statusTone(r,s=null){
  const raw=String(r?.market_status||'').toUpperCase();
  if(['PAYOUT_RECEIVED','PAID'].includes(raw))return'success';
  if(['SOLD_WAITING_PAYMENT','SOLD_UNDELIVERED'].includes(raw))return'warning';
  if(raw==='NOT_LISTED')return'info';
  return tone(s);
}

function rowMenu(r,{source=true}={}){
  const links=[
    r?.viagogo_url?`<a href="${h(r.viagogo_url)}" target="_blank" rel="noopener noreferrer">Viagogo ↗</a>`:'',
    r?.stubhub_url?`<a href="${h(r.stubhub_url)}" target="_blank" rel="noopener noreferrer">StubHub ↗</a>`:''
  ].filter(Boolean).join('');
  return `<div class="td500-row-menu"><button class="td500-row-menu-toggle" type="button" data-row-menu-toggle aria-label="Další akce" aria-expanded="false">•••</button><div class="td500-row-menu-panel" data-row-menu-panel><button type="button" data-ticket-detail="${h(r.id)}">Otevřít detail</button>${source?`<button type="button" data-ticket-source="${h(r.id)}">${r.stubhub_url?'Upravit zdroj':'Doplnit zdroj'}</button>`:''}${links}</div></div>`;
}

function inventoryCard(r,s){
  const p=potential(r,s);
  const market=n(s?.market_price_czk)||n(s?.stubhub_price_czk);
  const recommended=n(s?.recommended_ask_czk)||market;
  const ask=n(r.ask_each_czk);
  const targetEach=ask||recommended||market;
  const targetTotal=targetEach*qty(r);
  const d=eventDateParts(r);
  const pl=platform(r);
  const vis=visualFor(r.event_name);
  const t=statusTone(r,s);
  const health=apiHealth(s);
  const conf=confidence(s);
  const reason=s?.recommendation_reason||s?.source_message||'Čekám na další ověření trhu.';
  return `<article class="td331-ticket td500-ticket-row" role="row" data-inventory-card data-group="${actionCode(s)?'action':'hold'}" data-tone="${t}" data-ticket-id="${h(r.id)}">
    <div class="td500-event-cell" role="cell" data-col="event">
      <div class="td500-event-thumb ${vis.key}" aria-hidden="true"><span>${vis.icon}</span></div>
      <div class="td500-event-copy"><h3>${h(r.event_name||'Neznámá akce')}</h3><div class="td331-meta">${h(r.section||'Sektor neuveden')}${r.row_label?` · řada ${h(r.row_label)}`:''}</div><small class="td500-mobile-reason">${h(reason)}</small></div>
    </div>
    <div class="td500-cell td500-date" role="cell" data-col="date" data-label="Datum"><b>${h(d.date)}</b><small>${h(d.time)}</small></div>
    <div class="td500-cell" role="cell" data-col="platform" data-label="Platforma"><span class="td500-platform ${pl.key}">${h(pl.name)}</span></div>
    <div class="td500-cell td500-center" role="cell" data-col="qty" data-label="Počet"><b>${qty(r)}</b></div>
    <div class="td500-cell" role="cell" data-col="buy" data-label="Nákup"><b>${price(buyTotal(r))}</b><small>${price(r.buy_each_czk)} / ks</small></div>
    <div class="td500-cell" role="cell" data-col="sell" data-label="Prodej"><b>${price(targetTotal)}</b><small>${targetEach?`${price(targetEach)} / ks`:'bez ceny'}</small></div>
    <div class="td500-cell td500-profit ${Number.isFinite(p)?p>=0?'positive':'negative':''}" role="cell" data-col="profit" data-label="Zisk"><b>${signedMoney(p)}</b><small>${health.vg||health.sh?`jistota ${conf} %`:'data neúplná'}</small></div>
    <div class="td500-cell" role="cell" data-col="status" data-label="Stav"><span class="td331-badge ${t}">${h(status(r.market_status))}</span><small class="td500-verdict">${h(verdict(s))}</small></div>
    <div class="td500-actions-cell" role="cell" data-col="actions">${rowMenu(r)}</div>
  </article>`;
}

function soldCard(r){
  const profit=soldProfit(r);
  const d=eventDateParts(r);
  const pl=platform(r);
  const vis=visualFor(r.event_name);
  const isPaid=paid(r);
  const t=statusTone(r);
  const buy=buyTotal(r);
  const sellValue=sellTotal(r);
  const roi=buy?profit/buy*100:0;
  return `<article class="td331-ticket td331-sold-card td500-ticket-row" role="row" data-sold-card data-payout="${isPaid?'paid':'pending'}" data-tone="${t}" data-ticket-id="${h(r.id)}">
    <div class="td500-event-cell" role="cell" data-col="event">
      <div class="td500-event-thumb ${vis.key}" aria-hidden="true"><span>${vis.icon}</span></div>
      <div class="td500-event-copy"><h3>${h(r.event_name||'Neznámá akce')}</h3><div class="td331-meta">${h(r.section||'Sektor neuveden')}${r.row_label?` · řada ${h(r.row_label)}`:''}</div><small class="td500-mobile-reason">${isPaid?'Payout je uzavřený.':'Prodej je hotový, čeká se na dokončení payoutu.'}</small></div>
    </div>
    <div class="td500-cell td500-date" role="cell" data-col="date" data-label="Datum"><b>${h(d.date)}</b><small>${h(d.time)}</small></div>
    <div class="td500-cell" role="cell" data-col="platform" data-label="Platforma"><span class="td500-platform ${pl.key}">${h(pl.name)}</span></div>
    <div class="td500-cell td500-center" role="cell" data-col="qty" data-label="Počet"><b>${qty(r)}</b></div>
    <div class="td500-cell" role="cell" data-col="buy" data-label="Nákup"><b>${price(buy)}</b><small>${price(r.buy_each_czk)} / ks</small></div>
    <div class="td500-cell" role="cell" data-col="sell" data-label="Prodej"><b>${price(sellValue)}</b><small>${price(r.sell_each_czk)} / ks</small></div>
    <div class="td500-cell td500-profit ${profit>=0?'positive':'negative'}" role="cell" data-col="profit" data-label="Zisk"><b>${signedMoney(profit)}</b><small>ROI ${roi>=0?'+':''}${roi.toFixed(1)} %</small></div>
    <div class="td500-cell" role="cell" data-col="status" data-label="Stav"><span class="td331-badge ${t}">${h(status(r.market_status))}</span></div>
    <div class="td500-actions-cell" role="cell" data-col="actions">${rowMenu(r,{source:false})}</div>
  </article>`;
}

function tableHead(){
  return `<div class="td500-table-head" role="row">
    <span role="columnheader" data-col="event">Event</span>
    <span role="columnheader" data-col="date">Datum <i>↕</i></span>
    <span role="columnheader" data-col="platform">Platforma</span>
    <span role="columnheader" data-col="qty">Počet</span>
    <span role="columnheader" data-col="buy">Nákup</span>
    <span role="columnheader" data-col="sell">Prodej</span>
    <span role="columnheader" data-col="profit">Zisk</span>
    <span role="columnheader" data-col="status">Stav</span>
    <span role="columnheader" data-col="actions" aria-label="Akce"></span>
  </div>`;
}

function columnMenu(){
  const labels={date:'Datum',platform:'Platforma',qty:'Počet',buy:'Nákup',sell:'Prodej',profit:'Zisk',status:'Stav'};
  return `<div class="td500-columns-menu" data-columns-menu>${COLUMNS.map(key=>`<label><input type="checkbox" data-column-toggle="${key}" checked><span>${labels[key]}</span></label>`).join('')}</div>`;
}

function profitChart(rows){
  const sorted=[...rows].sort((a,b)=>String(a.event_date||'').localeCompare(String(b.event_date||'')));
  let total=0;
  const values=[0,...sorted.map(r=>(total+=soldProfit(r)))];
  while(values.length<6)values.push(total);
  const w=260,hg=76,pad=5;
  const min=Math.min(0,...values),max=Math.max(1,...values),range=Math.max(1,max-min);
  const points=values.map((v,i)=>{
    const x=pad+(w-pad*2)*(i/Math.max(1,values.length-1));
    const y=hg-pad-(hg-pad*2)*((v-min)/range);
    return[x,y];
  });
  const line=points.map((p,i)=>`${i?'L':'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const area=`${line} L${points.at(-1)[0].toFixed(1)} ${hg-pad} L${points[0][0].toFixed(1)} ${hg-pad} Z`;
  return{line,area,total};
}

function nextEvent(current){
  const now=Date.now();
  return [...current].filter(r=>Number.isFinite(Date.parse(r.event_date||''))&&Date.parse(r.event_date)>=now-86400000).sort((a,b)=>Date.parse(a.event_date)-Date.parse(b.event_date))[0]||null;
}

function bestPosition(cloud,s){
  const candidates=[
    ...s.current.map(r=>({r,value:potential(r,latest(cloud,r.id))})),
    ...s.soldRows.map(r=>({r,value:soldProfit(r)}))
  ].filter(x=>Number.isFinite(x.value));
  return candidates.sort((a,b)=>b.value-a.value)[0]||null;
}

function lowerPosition(cloud,s){
  return s.current.find(r=>code(latest(cloud,r.id))==='LOWER')||s.current.find(r=>tone(latest(cloud,r.id))==='critical')||null;
}

function sidePanel(cloud,s){
  const chart=profitChart(s.soldRows);
  const best=bestPosition(cloud,s);
  const lower=lowerPosition(cloud,s);
  const next=nextEvent(s.current);
  const top=s.current.find(r=>actionCode(latest(cloud,r.id)))||s.current[0]||null;
  const nextDays=next?Math.max(0,Math.ceil((Date.parse(next.event_date)-Date.now())/86400000)):null;
  return `<aside class="td500-side" data-ticket-side500 aria-label="Ticket přehled">
    <section class="td500-profit-card">
      <div class="td500-side-head"><div><span>Vývoj zisku</span><b>${signedMoney(s.realizedProfit)}</b></div><small class="${s.realizedProfit>=0?'positive':'negative'}">${s.realizedProfit>=0?'↑':'↓'} realizováno</small></div>
      <svg class="td500-profit-chart" viewBox="0 0 260 76" role="img" aria-label="Vývoj realizovaného zisku"><defs><linearGradient id="td500Area" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#1769ff" stop-opacity=".24"/><stop offset="1" stop-color="#1769ff" stop-opacity="0"/></linearGradient></defs><path class="area" d="${chart.area}"/><path class="line" d="${chart.line}"/><circle cx="${chart.line.match(/([0-9.]+) ([0-9.]+)$/)?.[1]||255}" cy="${chart.line.match(/([0-9.]+) ([0-9.]+)$/)?.[2]||38}" r="3.5"/></svg>
      <div class="td500-chart-legend"><span></span>Zisk (Kč)</div>
    </section>
    <div class="td500-insight-grid">
      <article><i class="green">♛</i><span>Nejlepší marže</span><b>${h(best?.r?.event_name||'Zatím bez dat')}</b><strong class="positive">${best?signedMoney(best.value):'—'}</strong></article>
      <article><i class="red">↓</i><span>Nutné zlevnit</span><b>${h(lower?.event_name||'Nic urgentního')}</b><strong class="${lower?'negative':''}">${lower?h(verdict(latest(cloud,lower.id))):'V pořádku'}</strong></article>
      <article><i class="blue">▣</i><span>Blíží se event</span><b>${h(next?.event_name||'Bez termínu')}</b><strong>${nextDays===null?'—':`za ${nextDays} dní`}</strong></article>
      <article><i class="orange">☼</i><span>Doporučení</span><b>${h(top?.event_name||'Portfolio je klidné')}</b><strong>${top?h(verdict(latest(cloud,top.id))):'Sledovat'}</strong></article>
    </div>
  </aside>`;
}

function opportunities(cloud,s){
  const rows=s.current.map(r=>({r,snap:latest(cloud,r.id),p:potential(r,latest(cloud,r.id))})).filter(x=>Number.isFinite(x.p)&&x.p>0).sort((a,b)=>b.p-a.p).slice(0,4);
  if(!rows.length)return'<div class="td331-empty">Jakmile bude k dispozici dost tržních dat, zobrazí se zde nejlepší příležitosti.</div>';
  return `<div class="td500-opportunity-grid">${rows.map(({r,snap,p})=>`<article class="td500-opportunity"><div><span>${h(verdict(snap))}</span><h3>${h(r.event_name||'Vstupenka')}</h3><p>${h(snap?.recommendation_reason||'Trh ukazuje prostor pro další krok.')}</p></div><strong>${signedMoney(p)}</strong><button type="button" data-ticket-detail="${h(r.id)}">Otevřít kartu →</button></article>`).join('')}</div>`;
}

function tipBar(cloud,s){
  const top=s.current.map(r=>({r,p:potential(r,latest(cloud,r.id))})).filter(x=>Number.isFinite(x.p)).sort((a,b)=>b.p-a.p)[0];
  const message=top?`Největší současný upside má ${top.r.event_name}: potenciál ${signedMoney(top.p)}. Před změnou ceny ověř shodu sektoru a počtu míst.`:'Nejdřív doplň zdroje a tržní ceny. Kamil OS pak zvýrazní, co koupit, prodat nebo zlevnit.';
  return `<section class="td500-tip" data-ticket-tip500><div class="td500-tip-icon">✣</div><b>Tip na příležitost:</b><p>${h(message)}</p><button type="button" data-tip-opportunities>Zobrazit příležitosti <span>→</span></button></section>`;
}

let deskMode='inventory';
let inventoryFilter='all';
let layoutMode='table';
let hiddenColumns=new Set();
try{
  layoutMode=localStorage.getItem('kamil.ticket.layout500')||'table';
  hiddenColumns=new Set(JSON.parse(localStorage.getItem('kamil.ticket.columns500')||'[]'));
}catch{}

function applyFilter(host,filter){
  inventoryFilter=['all','action','hold'].includes(filter)?filter:'all';
  host.querySelectorAll('[data-filter-choice]').forEach(x=>x.classList.toggle('on',x.dataset.filterChoice===inventoryFilter));
  host.querySelectorAll('[data-inventory-card]').forEach(x=>x.classList.toggle('hidden',inventoryFilter!=='all'&&x.dataset.group!==inventoryFilter));
  const label=host.querySelector('[data-filter-label]');
  if(label)label.textContent=inventoryFilter==='action'?'Akce':inventoryFilter==='hold'?'Držet':'Filtry';
}

function applyMode(host,mode){
  deskMode=MODE_SET.has(mode)?mode:'inventory';
  const root=host.querySelector('.td331')||host;
  root.dataset.ticketMode=deskMode;
  host.querySelectorAll('[data-td-mode]').forEach(x=>x.classList.toggle('on',x.dataset.tdMode===deskMode));
  host.querySelectorAll('[data-td-pane]').forEach(x=>{
    const pane=x.dataset.tdPane;
    const show=deskMode==='all'?pane==='inventory'||pane==='sold':deskMode==='purchases'?pane==='inventory':pane===deskMode;
    x.classList.toggle('hidden',!show);
  });
  if(window.__KAMIL_TICKET_DESK331__)window.__KAMIL_TICKET_DESK331__.mode=deskMode;
}

function applyLayout(host,mode){
  layoutMode=mode==='cards'?'cards':'table';
  const root=host.querySelector('.td331')||host;
  root.dataset.ticketLayout=layoutMode;
  host.querySelectorAll('[data-layout-toggle]').forEach(x=>x.classList.toggle('on',x.dataset.layoutToggle===layoutMode));
  try{localStorage.setItem('kamil.ticket.layout500',layoutMode);}catch{}
}

function applyColumns(host){
  const root=host.querySelector('.td331')||host;
  for(const key of COLUMNS)root.classList.toggle(`td500-hide-${key}`,hiddenColumns.has(key));
  host.querySelectorAll('[data-column-toggle]').forEach(x=>{x.checked=!hiddenColumns.has(x.dataset.columnToggle);});
  try{localStorage.setItem('kamil.ticket.columns500',JSON.stringify([...hiddenColumns]));}catch{}
}

async function editSource(cloud,id){
  const r=cloud.inventory.find(x=>String(x.id)===String(id));
  if(!r)return;
  const data=await formModal(`Zdroj · ${r.event_name}`,`<label class="field"><span>StubHub event URL</span><input name="url" type="url" value="${h(r.stubhub_url||'')}" placeholder="https://www.stubhub.com/.../event/123456789/"></label><p class="muted">Použij přímou stránku konkrétní akce.</p>`,{submitLabel:'Uložit'});
  if(!data)return;
  const url=String(data.url||'').trim();
  if(url&&!/^https:\/\/(?:[^/]+\.)?stubhub\.com\//i.test(url)){
    await modal('Neplatný odkaz','<p>Vlož přímý odkaz ze StubHub.</p>',[{label:'OK',value:null,primary:true}]);
    return;
  }
  const out=await updateTicketTracking660(r.id,{stubhubUrl:url||null});
  if(!out?.ok)throw out?.error||new Error('Uložení zdroje selhalo');
}

const inputNumber=value=>Number(String(value||'0').replace(/\s/g,'').replace(',','.'))||0;

async function addTicket(){
  const data=await formModal('Přidat vstupenku',`<div class="td500-form-grid">
    <label class="field wide"><span>Event</span><input name="event" autofocus required placeholder="Např. Sparta vs Slavia"></label>
    <label class="field"><span>Datum akce</span><input name="date" type="datetime-local" required></label>
    <label class="field"><span>Platforma</span><select name="platform"><option>Viagogo</option><option>Ticketmaster</option><option>Ticketportal</option><option>StubHub</option><option>Jiná</option></select></label>
    <label class="field"><span>Sektor</span><input name="section" placeholder="115 / C11"></label>
    <label class="field"><span>Řada</span><input name="row" placeholder="Volitelné"></label>
    <label class="field"><span>Počet kusů</span><input name="qty" type="number" min="1" value="2" required></label>
    <label class="field"><span>Nákup za kus</span><input name="buy" type="number" min="0" step="1" placeholder="0"></label>
    <label class="field"><span>Prodejní cena za kus</span><input name="ask" type="number" min="0" step="1" placeholder="Volitelné"></label>
    <label class="field"><span>Stav</span><select name="status"><option value="NOT_LISTED">Koupeno · zatím nenabízím</option><option value="LISTED">Nabídnuto k prodeji</option></select></label>
    <label class="field wide"><span>Viagogo URL</span><input name="viagogo" type="url" placeholder="https://www.viagogo.com/..."></label>
    <label class="field wide"><span>StubHub URL</span><input name="stubhub" type="url" placeholder="https://www.stubhub.com/..."></label>
  </div>`,{submitLabel:'Přidat vstupenku'});
  if(!data)return;
  const count=Math.max(1,inputNumber(data.qty));
  const buy=inputNumber(data.buy);
  const ask=inputNumber(data.ask);
  const row={
    id:`manual-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    eventName:String(data.event||'').trim(),
    eventDate:data.date?new Date(data.date).toISOString():null,
    section:String(data.section||'').trim()||null,
    rowLabel:String(data.row||'').trim()||null,
    qty:count,
    buyEachCzk:buy,
    buyTotalCzk:buy*count,
    askEachCzk:ask||null,
    marketStatus:String(data.status||'NOT_LISTED'),
    viagogoUrl:String(data.viagogo||'').trim()||null,
    stubhubUrl:String(data.stubhub||'').trim()||null,
    sourceName:String(data.platform||'Ruční zadání'),
    sourceSheet:'Ruční zadání'
  };
  const out=await upsertTicketInventory660([row],{syncLocal:false});
  if(!out?.ok)throw out?.error||new Error(out?.reason||'Uložení vstupenky selhalo');
  toast('Vstupenka byla přidána.');
  await requestRender(true);
}

let renderPromise=null,renderQueued=false,renderSeq=0,lastCanonicalHtml='';
const isTicketsEvent=e=>{const d=e?.detail;return d==='tickets'||d?.view==='tickets';};
function visible(){
  const section=document.querySelector('#view-tickets');
  const host=document.querySelector('#ticketIntelView');
  return !!host&&!!section?.classList.contains('on')&&getComputedStyle(host).display!=='none';
}

function ensureCss(){
  if(!document.querySelector('link[data-ticket-desk331]')){
    const l=document.createElement('link');
    l.rel='stylesheet';
    l.href='./ticketDesk331.css';
    l.dataset.ticketDesk331='1';
    document.head.appendChild(l);
  }
}

function paintError(host){
  lastCanonicalHtml='';
  host.innerHTML='<div class="td331"><section class="td331-hero"><div class="td331-kicker">Kamil OS · Ticket Portfolio</div><h1>Vstupenky se nepodařilo načíst.</h1><p>Data zůstala beze změny. Otevři Recovery Center nebo obnov stránku.</p><div class="td331-toolbar"><button class="td331-btn primary" data-retry>Načíst znovu</button><button class="td331-btn" data-recovery>Recovery Center</button></div></section></div>';
  host.querySelector('[data-retry]')?.addEventListener('click',()=>requestRender(true));
  host.querySelector('[data-recovery]')?.addEventListener('click',()=>openTicketRecoveryCenter185());
}

function toggleMenu(host,button,panel){
  const opening=!panel.classList.contains('open');
  host.querySelectorAll('.td500-popover.open,.td500-row-menu-panel.open,.td500-columns-menu.open').forEach(x=>{if(x!==panel)x.classList.remove('open');});
  host.querySelectorAll('[aria-expanded="true"]').forEach(x=>{if(x!==button)x.setAttribute('aria-expanded','false');});
  panel.classList.toggle('open',opening);
  button.setAttribute('aria-expanded',opening?'true':'false');
}

function bind(host,cloud){
  host.querySelectorAll('[data-td-mode]').forEach(x=>x.addEventListener('click',()=>applyMode(host,x.dataset.tdMode)));
  host.querySelectorAll('[data-filter-choice]').forEach(x=>x.addEventListener('click',()=>{applyFilter(host,x.dataset.filterChoice);x.closest('.td500-popover')?.classList.remove('open');}));
  host.querySelector('[data-filter-toggle]')?.addEventListener('click',e=>toggleMenu(host,e.currentTarget,host.querySelector('[data-filter-popover]')));
  host.querySelector('[data-tools-toggle]')?.addEventListener('click',e=>toggleMenu(host,e.currentTarget,host.querySelector('[data-tools-popover]')));
  host.querySelector('[data-columns-toggle]')?.addEventListener('click',e=>toggleMenu(host,e.currentTarget,host.querySelector('[data-columns-menu]')));
  host.querySelectorAll('[data-row-menu-toggle]').forEach(x=>x.addEventListener('click',e=>{e.stopPropagation();toggleMenu(host,x,x.nextElementSibling);}));
  host.querySelectorAll('[data-layout-toggle]').forEach(x=>x.addEventListener('click',()=>applyLayout(host,x.dataset.layoutToggle)));
  host.querySelectorAll('[data-column-toggle]').forEach(x=>x.addEventListener('change',()=>{const key=x.dataset.columnToggle;if(x.checked)hiddenColumns.delete(key);else hiddenColumns.add(key);applyColumns(host);}));
  host.querySelector('[data-add-ticket]')?.addEventListener('click',async()=>{try{await addTicket();}catch(err){await modal('Přidání selhalo',`<p>${h(err?.message||'Vstupenku se nepodařilo uložit.')}</p>`,[{label:'OK',value:null,primary:true}]);}});
  host.querySelectorAll('[data-refresh]').forEach(x=>x.addEventListener('click',async e=>{
    const b=e.currentTarget;
    b.disabled=true;
    b.textContent='Obnovuji…';
    try{await scanTicketsNow660(cloud.inventory||[]);await requestRender(true);}catch(err){
      b.disabled=false;
      b.textContent='Obnovit trh';
      await modal('Refresh selhal',`<p>${h(err?.message||'Nepodařilo se obnovit trh.')}</p>`,[{label:'OK',value:null,primary:true}]);
    }
  }));
  host.querySelector('[data-import]')?.addEventListener('click',async()=>{await openTicketExcelImport660();await requestRender(true);});
  host.querySelector('[data-export]')?.addEventListener('click',()=>exportTicketInventory660());
  host.querySelector('[data-commander]')?.addEventListener('click',()=>openTicketCommander660());
  host.querySelector('[data-recovery]')?.addEventListener('click',()=>openTicketRecoveryCenter185());
  host.querySelector('[data-seen]')?.addEventListener('click',async()=>{await markTicketAlertsSeen660((cloud.alerts||[]).map(x=>x.id));await requestRender(true);});
  host.querySelectorAll('[data-ticket-detail]').forEach(x=>x.addEventListener('click',()=>openTicketCommander660(x.dataset.ticketDetail)));
  host.querySelectorAll('[data-ticket-source]').forEach(x=>x.addEventListener('click',async()=>{try{await editSource(cloud,x.dataset.ticketSource);await requestRender(true);}catch(err){await modal('Uložení selhalo',`<p>${h(err?.message||'Zdroj se nepodařilo uložit.')}</p>`,[{label:'OK',value:null,primary:true}]);}}));
  host.querySelector('[data-open-all-actions]')?.addEventListener('click',()=>{const box=host.querySelector('[data-c465]');box?.classList.add('show-all');box?.scrollIntoView({behavior:'smooth',block:'start'});});
  host.querySelector('[data-tip-opportunities]')?.addEventListener('click',()=>applyMode(host,'opportunities'));
  applyMode(host,deskMode);
  applyFilter(host,inventoryFilter);
  applyLayout(host,layoutMode);
  applyColumns(host);
}

async function renderOnce(){
  const host=document.querySelector('#ticketIntelView');
  if(!host||!visible())return false;
  const seq=++renderSeq;
  if(!host.querySelector('.td331')){
    lastCanonicalHtml='';
    host.innerHTML='<div class="td331"><div class="td331-empty">Načítám přehled vstupenek…</div></div>';
  }
  const cloud=await loadTicketCloud660();
  if(seq!==renderSeq||!visible())return false;
  if(!cloud?.ok){paintError(host);return false;}

  const s=summary(cloud);
  const currentCards=[...s.current]
    .sort((a,b)=>Number(!actionCode(latest(cloud,a.id)))-Number(!actionCode(latest(cloud,b.id)))||String(a.event_date||'').localeCompare(String(b.event_date||'')))
    .map(r=>inventoryCard(r,latest(cloud,r.id))).join('');
  const soldCards=[...s.soldRows]
    .sort((a,b)=>String(b.event_date||'').localeCompare(String(a.event_date||'')))
    .map(soldCard).join('');
  let liveSources=0;
  for(const r of s.current){const q=apiHealth(latest(cloud,r.id));if(q.vg||q.sh)liveSources++;}

  const html=`<div class="td331" data-os340-ticket-portfolio data-ticket-layout="${h(layoutMode)}" data-ticket-mode="${h(deskMode)}">
    <section class="td331-hero">
      <div class="td331-kicker">Kamil OS · Ticket Portfolio</div>
      <h1>Ticket Trading Desk</h1>
      <p>Co udělat, kdy to udělat a jak chránit kapitál. Detailní modely jsou schované v analytice.</p>
      <div class="td331-toolbar">
        <button class="td331-btn primary td500-add" type="button" data-add-ticket><span>＋</span>Přidat vstupenku</button>
        <button class="td331-btn" type="button" data-import><span>⇧</span>Import</button>
        <div class="td500-menu-wrap"><button class="td331-btn" type="button" data-filter-toggle aria-expanded="false"><span>▽</span><span data-filter-label>Filtry</span></button><div class="td500-popover" data-filter-popover><strong>Zobrazit aktivní pozice</strong><button type="button" data-filter-choice="all">Všechny <b>${s.current.length}</b></button><button type="button" data-filter-choice="action">Čeká na akci <b>${s.actions}</b></button><button type="button" data-filter-choice="hold">Držet <b>${Math.max(0,s.current.length-s.actions)}</b></button></div></div>
        <div class="td500-menu-wrap td500-more-tools"><button class="td331-btn td500-icon-btn" type="button" data-tools-toggle aria-label="Další nástroje" aria-expanded="false">•••</button><div class="td500-popover td500-tools-popover" data-tools-popover><button type="button" data-refresh>↻ Obnovit trh</button><button type="button" data-export>⇩ Exportovat</button><button type="button" data-commander>◎ Otevřít Commander</button><button type="button" data-recovery>⚙ Recovery / diagnostika</button>${cloud.alerts?.length?`<button type="button" data-seen>✓ Přečteno (${cloud.alerts.length})</button>`:''}</div></div>
      </div>
    </section>

    <section class="td331-overview">
      <div class="td331-stat"><span class="td500-kpi-icon blue">⌁</span><span>Aktivní nabídky</span><b>${s.current.length}</b><small><em>↑</em> ${s.activeQty} ks právě v portfoliu</small></div>
      <div class="td331-stat"><span class="td500-kpi-icon purple">▣</span><span>Zakoupeno</span><b>${s.boughtQty}</b><small>${money(s.invested)} v aktivních pozicích</small></div>
      <div class="td331-stat"><span class="td500-kpi-icon green">✓</span><span>Prodáno</span><b>${s.soldQty}</b><small><em>↑</em> ${s.soldRows.length} uzavřených obchodů</small></div>
      <div class="td331-stat"><span class="td500-kpi-icon green">▤</span><span>Čistý zisk</span><b>${signedMoney(s.realizedProfit)}</b><small><em>↑</em> potenciál ${signedMoney(s.potentialProfit)}</small></div>
    </section>

    <nav class="td331-modes" aria-label="Ticket portfolio">
      <div class="td500-tabs">
        <button class="td331-mode" type="button" data-td-mode="inventory">Přehled</button>
        <button class="td331-mode" type="button" data-td-mode="purchases">Nákupy</button>
        <button class="td331-mode" type="button" data-td-mode="sold">Prodeje</button>
        <button class="td331-mode" type="button" data-td-mode="all">Inventář</button>
        <button class="td331-mode" type="button" data-td-mode="opportunities">Příležitosti</button>
      </div>
      <div class="td500-view-tools">
        <div class="td500-menu-wrap"><button class="td500-columns-btn" type="button" data-columns-toggle aria-expanded="false"><span>▥</span>Sloupce</button>${columnMenu()}</div>
        <div class="td500-layout-switch" aria-label="Zobrazení"><button type="button" data-layout-toggle="table" aria-label="Řádkové zobrazení">☷</button><button type="button" data-layout-toggle="cards" aria-label="Kartové zobrazení">☰</button></div>
      </div>
    </nav>

    <section class="td331-section" data-td-pane="inventory" aria-label="Aktivní vstupenky">
      ${tableHead()}
      <div class="td331-grid" role="rowgroup">${currentCards||'<div class="td331-empty">Zatím tu nejsou žádné aktivní vstupenky.</div>'}</div>
      <div class="td500-table-footer"><span>Zobrazeno ${s.current.length} aktivních pozic</span><span>${s.actions} čeká na rozhodnutí</span></div>
    </section>

    <section class="td331-section" data-td-pane="sold" aria-label="Prodané vstupenky">
      ${tableHead()}
      <div class="td331-grid" role="rowgroup">${soldCards||'<div class="td331-empty">Zatím tu nejsou žádné prodané vstupenky.</div>'}</div>
      <div class="td500-table-footer"><span>Realizovaný P/L ${signedMoney(s.realizedProfit)}</span><span>Čeká payout ${money(s.pendingPayout)}</span></div>
    </section>

    <section class="td331-section td500-opportunities-section" data-td-pane="opportunities" data-ticket-opportunities500 aria-label="Příležitosti">
      <div class="td500-opportunities-head"><div><span>PŘÍLEŽITOSTI</span><h2>Kde je teď největší prostor</h2><p>Řazeno podle potenciálního zisku z aktuálně dostupných tržních dat.</p></div><button type="button" data-refresh>Obnovit trh</button></div>
      ${opportunities(cloud,s)}
    </section>

    ${sidePanel(cloud,s)}
    ${tipBar(cloud,s)}

    <section class="td331-tech"><div class="left"><strong>Market data</strong><span class="td331-chip ${liveSources?'ok':'bad'}">${liveSources}/${s.current.length} aktivních se signálem</span><span class="td331-chip">single-owner renderer</span></div><button class="td331-btn" data-recovery>Recovery / diagnostika</button></section>
  </div>`;

  const changed=lastCanonicalHtml!==html;
  if(changed){
    host.innerHTML=html;
    lastCanonicalHtml=html;
    bind(host,cloud);
    window.dispatchEvent(new CustomEvent('kamil:ticket-desk331-updated',{detail:{portfolioVersion:340,inventory:s.current.length,sold:s.soldRows.length}}));
  }
  window.__KAMIL_TICKET_DESK331__={
    version:331,portfolioVersion:340,inventory:s.current.length,sold:s.soldRows.length,actions:s.actions,
    potentialProfit:s.potentialProfit,realizedProfit:s.realizedProfit,pendingPayout:s.pendingPayout,
    mode:deskMode,layout:layoutMode,renderedAt:Date.now(),refresh:()=>requestRender(true),stable:true,canonicalChanged:changed
  };
  return true;
}

function requestRender(force=false){
  if(renderPromise){renderQueued=renderQueued||force;return renderPromise;}
  renderPromise=renderOnce().catch(error=>{console.error('[ticketDesk331]',error);return false;}).finally(()=>{
    renderPromise=null;
    if(renderQueued){const queued=renderQueued;renderQueued=false;queueMicrotask(()=>requestRender(queued));}
  });
  return renderPromise;
}

export function installTicketDesk331(){
  ensureCss();
  if(document.documentElement.dataset.ticketDesk331==='1')return;
  document.documentElement.dataset.ticketDesk331='1';
  document.documentElement.dataset.ticketPortfolio340='1';
  window.addEventListener('kamil:view-change',e=>{if(isTicketsEvent(e))requestRender(false);});
  window.__KAMIL_TICKET_DESK331__={version:331,portfolioVersion:340,refresh:()=>requestRender(true),stable:true};
  if(document.querySelector('#view-tickets')?.classList.contains('on'))requestRender(false);
}
